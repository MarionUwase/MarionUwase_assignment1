package com.marion;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/login")
public class Login extends HttpServlet{
	private static final long serialVersionUID = 1L;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String correctEmail = "marion@auca.ac.rw";
        String correctPassword = "abcdefgh";

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email.equals(correctEmail) && password.equals(correctPassword)) {
            response.sendRedirect("homePage.html");
        } else {
            response.sendRedirect("PassRcover.html");
        }
    }
}



